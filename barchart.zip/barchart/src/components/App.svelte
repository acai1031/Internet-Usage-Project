<script>
  import { onMount } from 'svelte';
  import * as d3 from 'd3';
  import Internet from './Internet.svelte';

  let data = [];
  let filteredData = [];
  let svg;
  let selectedYear = 2000; // Default selected year
  let allowedYears = [2000, 2005, 2010, 2015, 2019, 2020, 2021];

  onMount(async () => {
    const res = await fetch('/internet_filtered.csv');
    const csv = await res.text();
    data = d3.csvParse(csv, d3.autoType);
    filteredData = data.filter(d => d.Year === selectedYear);
    drawChart();
  });

  // Reactive statement to update the chart when the selected year changes
  $: if (data.length > 0) {
    filteredData = data.filter(d => d.Year === selectedYear);
    drawChart();
  }

  let tooltipContent = ''; // Reactive variable to hold the tooltip content
  let tooltipStyle = 'visibility: hidden;'; // Start with the tooltip hidden

  function drawChart() {
    // Clear the previous chart
    d3.select(svg).selectAll("*").remove();

    // Set up dimensions and scales (adjust these as needed)
    const margin = { top: 20, right: 20, bottom: 60, left: 60 }; // Adjust bottom and left for axis labels
    const width = 1000 - margin.left - margin.right;
    const height = 400 - margin.top - margin.bottom;
    const x = d3.scaleBand()
      .range([0, width])
      .padding(0.1);
    const y = d3.scaleLinear()
      .range([height, 0]);

    // Append the SVG object to the body of the page
    const g = d3.select(svg)
      .append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

    // Process the data
    x.domain(filteredData.map(d => d['Region/Country/Area name']));
    y.domain([0, d3.max(filteredData, d => d.Value)]);

    // Add the bars with mouse event handlers for the tooltip
    g.selectAll(".bar")
      .data(filteredData)
      .enter().append("rect")
        .attr("class", "bar")
        .attr("x", d => x(d['Region/Country/Area name']))
        .attr("width", x.bandwidth())
        .attr("y", d => y(d.Value))
        .attr("height", d => height - y(d.Value))
        .on("mouseover", (event, d) => {
          tooltipContent = `Region: ${d['Region/Country/Area name']}, Value: ${d.Value}`;
          tooltipStyle = `visibility: visible; top: ${event.pageY + 10}px; left: ${event.pageX + 10}px;`;
        })
        .on("mousemove", (event) => {
          tooltipStyle = `visibility: visible; top: ${event.pageY + 10}px; left: ${event.pageX + 10}px;`;
        })
        .on("mouseout", () => {
          tooltipContent = '';
          tooltipStyle = 'visibility: hidden;';
        });
        
    g.append("g")
      .attr("transform", `translate(0,${height})`)
      .call(d3.axisBottom(x))
      .selectAll("text")
        .style("text-anchor", "end")
        .attr("dx", "-1em") // Adjust the dx value as needed
        .attr("dy", "-.5em") // Adjust the dy value as needed
        .attr("transform", "rotate(-75)"); // Increase the rotation angle

    // Add the y-axis
    g.append("g")
      .call(d3.axisLeft(y));

    // Add the bars
    g.selectAll(".bar")
      .data(filteredData)
      .enter().append("rect")
        .attr("class", "bar")
        .attr("x", d => x(d['Region/Country/Area name']))
        .attr("width", x.bandwidth())
        .attr("y", d => y(d.Value))
        .attr("height", d => height - y(d.Value));

    // Add x-axis label
    g.append("text")
      .attr("class", "axis-label")
      .attr("text-anchor", "end")
      .attr("x", width/2 + margin.left)
      .attr("y", height + margin.bottom + 50)
      .text("Areas");

    // Add y-axis label
    g.append("text")
      .attr("class", "axis-label")
      .attr("text-anchor", "end")
      .attr("transform", "rotate(-90)")
      .attr("y", -margin.left + 20)
      .attr("x", -height/2 + 60)
      .text("Internet Usage Value");

    
  }


  function updateYear(event) {
      let sliderValue = +event.target.value;
      selectedYear = allowedYears[sliderValue];
      drawChart(); 
    }
</script>

<main>
  <h1>Internet Usage Project</h1>
  <div class="slider-container">
    <input
      type="range"
      min="0"
      max="{allowedYears.length - 1}" 
      step="1" 
      value={allowedYears.indexOf(selectedYear)}
      on:input="{updateYear}"
    />
    <span class="year-label">{selectedYear}</span> <!-- Display the year next to the slider -->
  </div>
  <!-- Use {@html ...} to inject HTML content dynamically -->
  <div class="tooltip" style={tooltipStyle}>{@html tooltipContent}</div>
  <svg bind:this={svg} style="width: 100%; height: 500px;"></svg>
  <!-- Removed the duplicate div with id="tooltip" -->
  <Internet {data} />
</main>

<style>
  /* ... existing styles ... */

  .slider-container {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px; /* Adjust the space between the slider and the year label */
    margin: 20px 0; /* Add some margin around the slider for better spacing */
  }

  .year-label {
    font-size: 1em; /* Adjust the font size as needed */
    padding: 0 10px; /* Adjust padding as needed */
  }

  .tooltip {
    position: absolute;
    visibility: hidden;
    background-color: white;
    padding: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
    pointer-events: none;
    transition: opacity 0.3s;
    /* Ensure the tooltip is above other elements */
    z-index: 100;
  }
</style>
